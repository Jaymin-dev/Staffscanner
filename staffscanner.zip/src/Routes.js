import Dashboard from "./screens/Dashboard";

export default [
  {
    exact: true,
    path: "/",
    name: "Dashboard",
    component: Dashboard,
  },
];
