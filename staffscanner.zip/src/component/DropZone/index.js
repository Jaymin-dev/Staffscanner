import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import "./styles.scss";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDownload } from "@fortawesome/free-solid-svg-icons";
import { useDispatch } from "react-redux";
import { uploadImage } from "../../redux/actions/DashboardAction";

const DropZone = () => {
  const dispatch = useDispatch();
  const [uploadedFile, setUploadededFile] = useState([]);
  console.log("uploadedFile", uploadedFile);

  useEffect(() => {
    if (uploadedFile.length > 0) {
      // const fd = new FormData();
      // fd.append("file", uploadedFile[0]);
      // fd.append("sub_id", "2");
      // debugger;
      // dispatch(uploadImage(fd));
      console.log(" uploadedFile[0]", uploadedFile[0]);
      var formdata = new FormData();
      formdata.append("file", uploadedFile[0], uploadedFile[0].name);
      // formdata.append(
      //   "sub_id",
      //   "live_XvRm3aomU2eaD9zQAT7vMfeWbwhfv5E3eCRLSwLTu7TfMkMfVYefeYDfRoY461xP"
      // );
      var myHeaders = new Headers();
      myHeaders.append(
        "x-api-key",
        "live_XvRm3aomU2eaD9zQAT7vMfeWbwhfv5E3eCRLSwLTu7TfMkMfVYefeYDfRoY461xP"
      );
      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: formdata,
        redirect: "follow",
      };

      fetch("https://api.thecatapi.com/v1/images/upload", requestOptions).then(
        (r) => console.log("@@@@", r)
      );
    }
  }, [uploadedFile]);
  const handleChangeFile = (event) => {
    var formdata = new FormData();
    formdata.append("file", event.target.files[0], "cat1.jpeg");
    var myHeaders = new Headers();
    myHeaders.append(
      "x-api-key",
      "live_c7zjVeRNPLOhCR8tV2JLjjr6aXCPzBOAirCT0cSpSscZojanX3kejziTSHuiNc6u"
    );
    myHeaders.append(
      "sub_id",
      "live_c7zjVeRNPLOhCR8tV2JLjjr6aXCPzBOAirCT0cSpSscZojanX3kejziTSHuiNc6u"
    );
    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: formdata,
      redirect: "follow",
    };

    fetch("https://api.thecatapi.com/v1/images/upload", requestOptions).then(
      (r) => console.log("@@@@@@@@", r)
    );
  };

  return (
    <>
      <input type="file" name="fileToUploadNep" onChange={handleChangeFile} />
      {/*<Dropzone onDrop={(acceptedFiles) => setUploadededFile(acceptedFiles)}>*/}
      {/*  {({ getRootProps, getInputProps }) => (*/}
      {/*    <section className="dropzone-wrapper">*/}
      {/*      <div {...getRootProps()}>*/}
      {/*        <input {...getInputProps()} />*/}

      {/*        <div className="dropzone-wrapper-message">*/}
      {/*          <FontAwesomeIcon icon={faDownload} className="download-icon" />*/}
      {/*          <p>Upload a cat image</p>*/}
      {/*        </div>*/}
      {/*      </div>*/}
      {/*    </section>*/}
      {/*  )}*/}
      {/*</Dropzone>*/}
      {/*    */}
    </>
  );
};

export default DropZone;
