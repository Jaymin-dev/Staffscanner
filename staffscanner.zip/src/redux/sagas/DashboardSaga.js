import { all, call, put, takeLatest } from "redux-saga/effects";
import { Axios } from "../../api/axios";
import { getSimplifiedError } from "../../utils/error";
import {
  IMAGE_UPLOAD_REQUEST,
  IMAGE_UPLOAD_SUCCESS,
  IMAGE_UPLOAD_ERROR,
  GET_IMAGES_REQUEST,
  GET_IMAGES_SUCCESS,
  GET_IMAGES_ERROR,
  ADD_FAVOURITE_POST_REQUEST,
  ADD_FAVOURITE_POST_SUCCESS,
  ADD_FAVOURITE_POST_ERROR,
  DELETE_FAVOURITE_POST_REQUEST,
  DELETE_FAVOURITE_POST_SUCCESS,
  DELETE_FAVOURITE_POST_ERROR,
  SET_VOTES_REQUEST,
  SET_VOTES_SUCCESS,
  SET_VOTES_ERROR,
  LIST_VOTES_REQUEST,
  LIST_VOTES_SUCCESS,
  LIST_VOTES_ERROR,
} from "../reducers/DashboardReducer";

async function uploadImg(payload) {
  return await Axios.post("images/upload", payload);
}
function* handleUploadImg({ payload }) {
  try {
    debugger;
    const response = yield call(uploadImg, payload);
    if (response) {
      debugger;
      yield put({
        type: IMAGE_UPLOAD_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: IMAGE_UPLOAD_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

async function getAllImage(payload) {
  return await Axios.get("images", payload);
}
function* handleGetAllImages({ payload }) {
  try {
    const response = yield call(getAllImage, payload);
    if (response) {
      yield put({
        type: GET_IMAGES_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: GET_IMAGES_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

async function addFavouritePost(payload) {
  return await Axios.post("favourites/", payload);
}
function* handleAddFavouritePost({ payload }) {
  try {
    const response = yield call(addFavouritePost, payload);
    if (response) {
      debugger;
      yield put({
        type: ADD_FAVOURITE_POST_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: ADD_FAVOURITE_POST_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

async function deleteFavouritePost(payload) {
  const { id, ...data } = payload;
  return await Axios.delete(`favourites/${id}`, data);
}
function* handleDeleteFavouritePost({ payload }) {
  try {
    const response = yield call(deleteFavouritePost, payload);
    if (response) {
      debugger;
      yield put({
        type: DELETE_FAVOURITE_POST_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: DELETE_FAVOURITE_POST_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

async function setVotes(payload) {
  return await Axios.post(`votes`, payload);
}
function* handleSetVotes({ payload }) {
  try {
    const response = yield call(setVotes, payload);
    if (response) {
      debugger;
      yield put({
        type: SET_VOTES_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: SET_VOTES_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

async function listVotes(payload) {
  return await Axios.get(`votes`, payload);
}
function* handleListVotes({ payload }) {
  try {
    const response = yield call(listVotes, payload);
    if (response) {
      debugger;
      yield put({
        type: LIST_VOTES_SUCCESS,
      });
    }
  } catch (error) {
    yield put({
      type: LIST_VOTES_ERROR,
      payload: getSimplifiedError(error),
    });
  }
}

export default all([
  takeLatest(IMAGE_UPLOAD_REQUEST, handleUploadImg),
  takeLatest(GET_IMAGES_REQUEST, handleGetAllImages),
  takeLatest(ADD_FAVOURITE_POST_REQUEST, handleAddFavouritePost),
  takeLatest(DELETE_FAVOURITE_POST_REQUEST, handleDeleteFavouritePost),
  takeLatest(SET_VOTES_REQUEST, handleSetVotes),
  takeLatest(LIST_VOTES_REQUEST, handleListVotes),
]);
