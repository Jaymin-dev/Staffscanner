import React, { useEffect, useRef } from "react";
import VanillaTilt from "vanilla-tilt";
import "./styles.scss";
import Like from "../../component/Like";

const Card = () => {
  const tilt = useRef(null);
  const options = {
    scale: 1.05,
    speed: 1000,
    max: 20,
  };

  useEffect(() => {
    VanillaTilt.init(tilt.current, options);
  }, [options]);

  return (
    <div className="col-12 col-sm-8 col-md-6 col-lg-4">
      <div className="px-2 py-4">
        <div className="card" ref={tilt} options={options}>
          <img
            className="card-img"
            src="https://s3.eu-central-1.amazonaws.com/bootstrapbaymisc/blog/24_days_bootstrap/vans.png"
            alt="Vans"
          />
          <div className="card-img-overlay d-flex justify-content-end">
            <a href="#" className="card-link text-danger like">
              <Like />
            </a>
          </div>
          <div className="card-body">
            {/*<h4 className="card-title">Vans Sk8-Hi MTE Shoes</h4>*/}
            <h6 className="card-subtitle mb-2 text-muted">Style: VA33TXRJ5</h6>

            <div className="buy d-flex justify-content-between align-items-center">
              <div className="price text-success">
                <h5>125</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
