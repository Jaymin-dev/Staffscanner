import React, { useEffect } from "react";
import { ReactComponent as Logo } from "../../asset/images/logo.svg";
import Card from "./Card";
import UploadFile from "./UploadFile";
import { useDispatch } from "react-redux";
import { getAllImages } from "../../redux/actions/DashboardAction";

const Dashboard = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    console.log("@@");
    dispatch(getAllImages());
  }, []);

  return (
    <div className="container pt-5">
      <div className="d-flex justify-content-between mb-4">
        <Logo />
        <UploadFile />
      </div>
      <div className="container">
        <div className="row">
          <Card />
          <Card />
          <Card />
          <Card />
          <Card />
          <Card />
          <Card />
        </div>
      </div>
    </div>
  );
};
export default Dashboard;
